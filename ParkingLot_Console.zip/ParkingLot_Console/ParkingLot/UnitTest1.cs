﻿using System;
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParkingLot_Console.Interfaces;
using ParkingLot_Console.BusinessLogic;
using System.Collections.Generic;
using ParkingLot_Console.Models;
using ParkingLot_Console.Enums;
using FluentAssertions;

namespace ParkingLot.Test
{
    [TestClass]
    public class UnitTest1
    {
        List<List<ParkingSpot>> layout = new List<List<ParkingSpot>>()
            {
                new List<ParkingSpot> ()
                    {
                        new ParkingSpot() { Row = 1, ParkingSpotTypes = ParkingSpotTypes.Small, StartPosition = 1, SpotCount = 4, SpotPrice = 20.00},
                        new ParkingSpot() { Row = 2, ParkingSpotTypes = ParkingSpotTypes.Compact, StartPosition = 11, SpotCount = 1, SpotPrice = 55.00},
                        new ParkingSpot() { Row = 3, ParkingSpotTypes = ParkingSpotTypes.Large, StartPosition = 21, SpotCount = 4, SpotPrice = 75.00}
                    }
            };

        [TestMethod]
        public void GetOptimalSpotShouldReturnFirstPosition()
        {
            var parkingLot = new ParkingLotCore(layout, new ParkingSpaceMapper());
            var vehicle = new Vehicle() { VehicleNumber = "One", vehicleType = VehicleTypes.Hatchback };
            var actual = parkingLot.GetOptimalParkingSpot(vehicle);
            var expected = new ParkingSpot() { ParkingSpotTypes = ParkingSpotTypes.Small, Row = 1, SpotCount = 1, StartPosition = 1, SpotPrice = 20.00 };
            actual.Should().BeEquivalentTo(expected);
        }

        [TestMethod]
        public void GetOptimalSpotShouldReturnNull()
        {
            var mockSpaceMapper = new Mock<IParkingSpaceMapper>();
            mockSpaceMapper.Setup(m => m.GetSmallestParkingSpaceRequired(It.IsAny<Vehicle>()))
                .Returns(new ParkingSpaceRequirment() { ParkingSpot = ParkingSpotTypes.Large, ParkingSpotsCount = 15 });
            var parkingLot = new ParkingLotCore(layout, mockSpaceMapper.Object);
            var parkingSpot = parkingLot.GetOptimalParkingSpot(new Vehicle() { VehicleNumber = "Two", vehicleType = VehicleTypes.MiniTruck });
            parkingSpot.Should().BeNull();
        }

        [TestMethod]
        public void ParkVehicleShouldReturnTrue()
        {
            var parkingLot = new ParkingLotCore(layout, new ParkingSpaceMapper());
            ParkingSpot spot = new ParkingSpot { Row = 1, ParkingSpotTypes = ParkingSpotTypes.Small, StartPosition = 1, SpotCount = 2, SpotPrice = 20.00 };
            var vehicle = new Vehicle() { VehicleNumber = "One", vehicleType = VehicleTypes.Hatchback };
            var actual = parkingLot.ParkVehicle(vehicle, spot);
            actual.Should().BeTrue();
        }
    }
}
