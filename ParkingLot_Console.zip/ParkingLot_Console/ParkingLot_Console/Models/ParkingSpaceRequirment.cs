﻿using ParkingLot_Console.Enums;

namespace ParkingLot_Console.Models
{
    public class ParkingSpaceRequirment
    {
        public ParkingSpotTypes ParkingSpot { get; set; }
        public int ParkingSpotsCount { get; set; }
    }
}
