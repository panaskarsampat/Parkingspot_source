﻿using ParkingLot_Console.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParkingLot_Console.Models
{
    public class Vehicle
    {
        public string VehicleNumber { get; set; }
        public VehicleTypes vehicleType { get; set; }
    }
}
