﻿using ParkingLot_Console.Enums;

namespace ParkingLot_Console.Models
{
    public class ParkingSpot
    {        
        public int Row { get; set; }
        public int StartPosition { get; set; }
        public int SpotCount { get; set; }
        public double? SpotPrice { get; set; }
        public ParkingSpotTypes ParkingSpotTypes { get; set; }
    }
}
