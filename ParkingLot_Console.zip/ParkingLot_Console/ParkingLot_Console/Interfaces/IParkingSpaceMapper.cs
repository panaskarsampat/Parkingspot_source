﻿using ParkingLot_Console.Models;

namespace ParkingLot_Console.Interfaces
{
    public interface IParkingSpaceMapper
    {
        ParkingSpaceRequirment GetSmallestParkingSpaceRequired(Vehicle vehicle);
    }
}
