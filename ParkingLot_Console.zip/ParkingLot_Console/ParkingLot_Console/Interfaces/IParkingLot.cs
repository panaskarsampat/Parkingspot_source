﻿using ParkingLot_Console.Enums;
using ParkingLot_Console.Models;

namespace ParkingLot_Console.Interfaces
{
    public interface IParkingLot
    {
        int FreeSpots { get; }
        bool ParkVehicle(Vehicle vehicle, ParkingSpot parkingSpot);
        bool UnParkvehicle(Vehicle vehicle);
        ParkingSpot GetOptimalParkingSpot(Vehicle vehicle);
        ParkingSpotStatus GetParkingSpotStatus(ParkingSpot spot);
    }
}
