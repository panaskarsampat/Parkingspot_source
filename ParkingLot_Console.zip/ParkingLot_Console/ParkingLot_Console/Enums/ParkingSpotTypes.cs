﻿namespace ParkingLot_Console.Enums
{
    public enum ParkingSpotTypes
    {
        Small = 0,
        Compact = 1,
        Large = 2
    }
}
