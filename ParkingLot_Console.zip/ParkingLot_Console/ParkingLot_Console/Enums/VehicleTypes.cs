﻿namespace ParkingLot_Console.Enums
{
    public enum VehicleTypes
    {
        Hatchback = 0,
        Sedan = 1,
        MiniTruck = 2
    }
}
