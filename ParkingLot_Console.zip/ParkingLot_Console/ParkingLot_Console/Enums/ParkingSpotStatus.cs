﻿namespace ParkingLot_Console.Enums
{
    public enum ParkingSpotStatus
    {
        Occupied = 0,
        Vacant = 1
    }
}
