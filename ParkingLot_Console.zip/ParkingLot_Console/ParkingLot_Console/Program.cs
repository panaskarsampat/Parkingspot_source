﻿using ParkingLot_Console.BusinessLogic;
using ParkingLot_Console.Enums;
using ParkingLot_Console.Models;
using System;
using System.Collections.Generic;

namespace ParkingLot_Console
{
    class Program
    {
        static void Main(string[] args)
        {

            List<List<ParkingSpot>> layout = new List<List<ParkingSpot>>()
            {
                new List<ParkingSpot> () //Row
                {
                    new ParkingSpot() { Row = 1, ParkingSpotTypes = ParkingSpotTypes.Small, StartPosition = 1, SpotCount = 4, SpotPrice = 20.00},                    
                    new ParkingSpot() { Row = 2, ParkingSpotTypes = ParkingSpotTypes.Compact, StartPosition = 11, SpotCount = 1, SpotPrice = 55.00},
                    new ParkingSpot() { Row = 3, ParkingSpotTypes = ParkingSpotTypes.Large, StartPosition = 21, SpotCount = 4, SpotPrice = 75.00}
                }
            };

            ParkingLotCore _parkingLotCore = new ParkingLotCore(layout, new ParkingSpaceMapper());

            //Vehicle _vehical = new Vehicle() {
            //    VehicleNumber="1",
            //    vehicleType=VehicleTypes.Hatchback
            //};

            //ParkingSpot res = _parkingLotCore.GetOptimalParkingSpot(_vehical);

            Vehicle _vehical = new Vehicle();
            //{
            //    VehicleNumber = "2021",
            //    vehicleType = VehicleTypes.MiniTruck
            //};

            Console.WriteLine("******************************************");
            Console.WriteLine("Car Type Code & Name");
            Console.WriteLine("0. Hatchback 1. Sedan 2. Mini-Truck");
            Console.WriteLine();
            Console.Write("Enter Car Type Code : ");

            int cType = Convert.ToInt32(Console.ReadLine());
            VehicleTypes _vehicalType = (VehicleTypes)cType;
            
            _vehical.vehicleType = _vehicalType;
            Console.WriteLine();
            Console.Write("Enter Car Number : ");

            _vehical.VehicleNumber = Console.ReadLine();

            ParkingSpot res = _parkingLotCore.GetOptimalParkingSpot(_vehical);

            Console.WriteLine("******************************************");

            if (res != null)
            {
                Console.WriteLine(" Parking Spot Available.");
                Console.WriteLine(" Parking Spot Types: {0}", res.ParkingSpotTypes);
                Console.WriteLine(" Row Number: {0}", res.Row);
                Console.WriteLine(" Start Position: {0}", res.StartPosition);
                Console.WriteLine(" Spot Count: {0}", res.SpotCount);
                Console.WriteLine(" Parking Price: {0}", res.SpotPrice);                
            }
            else
            {
                Console.WriteLine(" Parking Spot Not Available...Good Day!!!");
            }

            Console.WriteLine("******************************************");
            Console.ReadLine();
        }
    }
}
