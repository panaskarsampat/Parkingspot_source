﻿using ParkingLot_Console.Enums;
using ParkingLot_Console.Interfaces;
using ParkingLot_Console.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading;

namespace ParkingLot_Console.BusinessLogic
{
    public class ParkingLotCore : IParkingLot
    {
        private ImmutableSortedSet<ParkingSpot> freeParkingSpots;
        private ConcurrentDictionary<string, ParkingSpot> parkedVehicles;
        private readonly IEnumerable<List<ParkingSpot>> parkingLotLayout;
        private readonly IParkingSpaceMapper parkingSpaceMapper;
        private int _freeSpots = 0;
        public int FreeSpots => _freeSpots;
        private int _totalSpots = 0;
        public int TotalSpots => _totalSpots;

        public ParkingLotCore(IEnumerable<List<ParkingSpot>> parkingLotLayout, IParkingSpaceMapper parkingSpaceMapper)
        {
            var comparer = Comparer<ParkingSpot>.Create((x, y) =>
                x.Row==y.Row?
                x.StartPosition.CompareTo(y.StartPosition):x.Row.CompareTo(y.Row)
            );

            freeParkingSpots = ImmutableSortedSet.Create<ParkingSpot>(comparer);
            parkedVehicles = new ConcurrentDictionary<string, ParkingSpot>();
            this.parkingLotLayout = parkingLotLayout;
            this.parkingSpaceMapper = parkingSpaceMapper;
            InitializeParkingLot();
        }
        
        //Initialize the Master Data
        private void InitializeParkingLot()
        {
            foreach(var row in parkingLotLayout)
            {
                foreach(var spot in row)
                {
                    freeParkingSpots = freeParkingSpots.Add(spot);
                    Interlocked.Add(ref _totalSpots, spot.SpotCount);
                    Interlocked.Add(ref _freeSpots, spot.SpotCount);
                }
            }
        }

        //Get Details of Allocated Parking Spot.
        public ParkingSpot GetOptimalParkingSpot(Vehicle vehicle)
        {
            ParkingSpaceRequirment requiredSpace = parkingSpaceMapper.GetSmallestParkingSpaceRequired(vehicle);
            var vacantSpot = freeParkingSpots.FirstOrDefault(m => m.ParkingSpotTypes >= requiredSpace.ParkingSpot
            && m.SpotCount >= requiredSpace.ParkingSpotsCount
            );
            if (vacantSpot != null)
            {
                vacantSpot.SpotCount = Math.Min(vacantSpot.SpotCount, requiredSpace.ParkingSpotsCount);
            }
            return vacantSpot;
        }

        //Get the Status Parking Spot, which are the spot avaliable.
        public ParkingSpotStatus GetParkingSpotStatus(ParkingSpot spot)
        {
            var rightSpot = freeParkingSpots.FirstOrDefault(s => s.Row == spot.Row
             && spot.ParkingSpotTypes == spot.ParkingSpotTypes
             && spot.StartPosition <= spot.StartPosition
             && spot.StartPosition + spot.SpotCount >= spot.SpotCount + spot.StartPosition
            );
            if (rightSpot != null)
            {
                return ParkingSpotStatus.Vacant;
            }
            return ParkingSpotStatus.Occupied;
        }

        public bool ParkVehicle(Vehicle vehicle, ParkingSpot parkingSpot)
        {
            throw new NotImplementedException();
        }

        public bool UnParkvehicle(Vehicle vehicle)
        {
            throw new NotImplementedException();
        }
    }
}
