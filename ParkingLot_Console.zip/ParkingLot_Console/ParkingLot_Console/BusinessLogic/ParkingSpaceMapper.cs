﻿using ParkingLot_Console.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ParkingLot_Console.Models;
using ParkingLot_Console.Enums;

namespace ParkingLot_Console.BusinessLogic
{
    public class ParkingSpaceMapper : IParkingSpaceMapper
    {
        public ParkingSpaceRequirment GetSmallestParkingSpaceRequired(Vehicle vehicle)
        {
            switch (vehicle.vehicleType)
            {
                case VehicleTypes.Hatchback:
                    return new ParkingSpaceRequirment()
                    {
                        ParkingSpot = ParkingSpotTypes.Small,
                        ParkingSpotsCount = 1                        
                    };
                case VehicleTypes.Sedan:
                    return new ParkingSpaceRequirment()
                    {
                        ParkingSpot = ParkingSpotTypes.Compact,
                        ParkingSpotsCount=2
                    };
                case VehicleTypes.MiniTruck:
                    return new ParkingSpaceRequirment()
                    {
                        ParkingSpot=ParkingSpotTypes.Large,
                        ParkingSpotsCount=5
                    };
                default:
                    throw new ArgumentException($"vehicleType {vehicle.vehicleType} is invalid.");
            }            
        }
    }
}
